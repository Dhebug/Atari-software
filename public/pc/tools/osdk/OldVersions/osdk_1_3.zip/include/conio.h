/*
 For contiki 
*/

#define kbhit key
#define cgetc get

