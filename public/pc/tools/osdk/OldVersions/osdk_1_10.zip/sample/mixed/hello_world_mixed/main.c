//
// TEST_3
//
// This is a "HELLO WORLD" sample using
// an assembly code routine to display
// the message
//


// Declare the assembly code function
void SimplePrint(const char *ptr_message);


void main()
{
	SimplePrint("Hello World !");
}
